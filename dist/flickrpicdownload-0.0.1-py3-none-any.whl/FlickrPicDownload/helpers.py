class helps:
    def __init__(self):
        pass

    def __repr__(self):
        return 'You need other packages to run it. Using .packages to see the package requirements.'

class packages:
    def __init__(self):
        pass

    def __repr__(self):
        return 'requests, bs4, random, re, json and flickrapi'

class figuresizes:
    def __init__(self):
        pass

    def __repr__(self):
        return "['Square', 'Large Square', 'Thumbnail', 'Small', 'Small 320', 'Small 400', 'Medium', 'Medium 640', 'Medium 800', 'Large', 'Large 1600', 'Large 2048', 'X-Large 3K', 'X-Large 4K']"